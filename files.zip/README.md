# Sports Prophet v3

A full-stack sports betting research system combining a Python autonomous backend, a FastAPI REST server, and a dark-mode frontend with every major bet type — all in one repo.

---

## What's inside

```
sports_prophet/
├── backend/
│   ├── core.py           # Autonomous scheduler, Elo engine, DB, learning
│   ├── server.py         # FastAPI REST API (all endpoints)
│   └── requirements.txt
├── frontend/
│   └── index.html        # Full single-file app (no build step)
└── README.md
```

---

## Features

### Prediction engine
- **Elo-based win probability** — same formula used by FiveThirtyEight
- **Monte Carlo simulation** — 10,000 games per prediction
- **Expected value (EV)** — calculates edge vs bookmaker price
- **Kelly criterion** — optimal bankroll sizing (25% fractional Kelly)
- **Confidence levels** — HIGH / MEDIUM / LOW / PASS with unit sizing

### Every bet type
| Type | What it calculates |
|------|-------------------|
| Moneyline | EV, implied prob, edge vs market |
| Spread / ATS | Key number proximity, EV, cover probability |
| Total (O/U) | Over/Under EV, near-key-number warning |
| Parlay | Combined EV, leg-by-leg vig breakdown |
| Player Prop | Over/Under EV, Kelly sizing |
| Futures | Long-term EV, reduced Kelly sizing |
| Teaser | Key number crossings (3, 7), value assessment |

### AI Research Assistant
- Powered by Claude API with live web search
- Follows the full research protocol (injury report → rest/schedule → form → lines → recommendation)
- Edge priority rankings by sport (NBA, NFL, MLB, NHL, Soccer)
- Confidence calibration: HIGH/MEDIUM/LOW/PASS with unit guidance

### Tracking & Analytics
- **Bet tracker** — log every bet with EV and confidence
- **Bankroll stats** — ROI, win rate, P/L by confidence level and bet type
- **Calibration chart** — do your 65% picks win 65% of the time?
- **CLV tracking** — closing line value explained

### Situational edges database
- NBA: Back-to-back, 4-in-5, rest advantages
- NFL: Short week, post-bye, divisional dogs
- MLB: Bullpen fatigue, ace vs opener, travel spots
- NHL: Backup goalie on B2B, special teams edge

### Autonomous backend
- SQLite database with full schema (games, injuries, lines, analyses, bets, patterns)
- Scheduled tasks: morning protocol, injury monitor (15min), line tracker (10min), weather (6hr), pattern learning (daily 3am), performance audit (weekly)
- Learning engine: rest advantage, injury impact, line movement pattern analysis
- Search orchestrator with 15-minute caching and rate limiting

---

## Quick start

### Backend (optional — frontend works standalone)

```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --reload --port 8000
```

API docs available at `http://localhost:8000/docs`

### Frontend

Open `frontend/index.html` directly in any browser. No build step required.

The AI Research Assistant requires an Anthropic API key. The frontend calls `https://api.anthropic.com/v1/messages` directly — add your key via a proxy or modify the fetch call to include your key.

---

## API endpoints

```
GET  /                          Health check
POST /predict                   Full game analysis (Elo + Monte Carlo + EV)
POST /simulate                  Monte Carlo simulation only
POST /bets/moneyline             Moneyline EV calculation
POST /bets/spread                Spread EV + key number analysis
POST /bets/total                 Total EV + key number analysis
POST /bets/parlay                Parlay combined EV + vig breakdown
POST /bets/prop                  Player prop EV calculation
POST /bets/futures               Futures EV + reduced Kelly sizing
POST /bets/teaser                Teaser key number crossing analysis
POST /bets/live                  Pre-game CLV baseline for live betting
GET  /odds/convert               American ↔ decimal ↔ fractional converter
GET  /odds/ev                    EV calculator
GET  /odds/kelly                 Kelly criterion calculator
POST /tracker/save               Save bet to database
POST /tracker/settle             Settle bet with outcome
GET  /tracker/history            Bet history
GET  /tracker/stats              Bankroll statistics
GET  /research/patterns          Discovered learning patterns
GET  /research/schedule_spots    Situational edge frameworks
```

---

## Sample API call

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "sport": "nba",
    "team_a": "Lakers",
    "team_b": "Warriors",
    "rating_a": 1600,
    "rating_b": 1550,
    "odds_a": 1.85,
    "odds_b": 2.10,
    "total_line": 225.5,
    "spread": -4.5
  }'
```

---

## Adding real data sources

Replace the stub methods in `SearchOrchestrator` with real API calls:

| Data type | Recommended source |
|-----------|-------------------|
| Injuries | RotoWire, official league injury reports |
| Live odds | The Odds API (free tier available) |
| Team stats | SportsRadar, ESPN API |
| Weather | OpenWeatherMap, National Weather Service |
| Line movement | Pinnacle API, Betfair Exchange |
| Schedule | Official league APIs |

---

## Disclaimer

This tool is for research and educational purposes. Sports betting involves risk. Always verify information before betting. Past model accuracy does not guarantee future results. Bet responsibly.
