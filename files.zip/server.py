#!/usr/bin/env python3
"""
Sports Prophet — FastAPI Server
Exposes REST endpoints for the frontend and autonomous system.
"""

import asyncio
import json
import math
import random
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from core import AnalysisEngine, DatabaseManager, SearchOrchestrator

# ─────────────────────────────────────────────
app = FastAPI(title="Sports Prophet API", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

db     = DatabaseManager()
search = SearchOrchestrator(db)
engine = AnalysisEngine(db, search)

# ─────────────────────────────────────────────
#  Request / Response Models
# ─────────────────────────────────────────────

class GameInput(BaseModel):
    sport:       str          = Field(..., example="nba")
    team_a:      str          = Field(..., example="Lakers")
    team_b:      str          = Field(..., example="Warriors")
    rating_a:    float        = Field(1600, ge=1000, le=2200)
    rating_b:    float        = Field(1550, ge=1000, le=2200)
    odds_a:      float        = Field(1.85, description="Decimal odds for team A")
    odds_b:      float        = Field(2.10, description="Decimal odds for team B")
    total_line:  Optional[float] = None
    spread:      Optional[float] = None

class BetRecord(BaseModel):
    matchup:        str
    sport:          str
    bet_type:       str
    selection:      str
    odds:           float
    units:          float
    predicted_prob: Optional[float] = None
    ev:             Optional[float] = None
    confidence:     Optional[str]   = None
    game_id:        Optional[str]   = None

class OutcomeUpdate(BaseModel):
    bet_id:   str
    outcome:  str   # "win" | "loss" | "push" | "void"

class ParleyLeg(BaseModel):
    selection: str
    odds:      float
    prob:      float

class ParlayInput(BaseModel):
    legs:  list[ParleyLeg]
    units: float = 1.0

class PropInput(BaseModel):
    player:    str
    stat:      str
    line:      float
    over_odds: float
    under_odds: float
    over_prob:  float

class LiveOddsInput(BaseModel):
    american_odds: int

# ─────────────────────────────────────────────
#  Core Prediction Endpoints
# ─────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "Sports Prophet v3 running", "date": datetime.now().isoformat()}


@app.post("/predict")
async def predict(game: GameInput):
    """Full game analysis — Elo + Monte Carlo + EV + Kelly."""
    analysis = await engine.full_game_analysis(
        sport    = game.sport,
        team_a   = game.team_a,
        team_b   = game.team_b,
        rating_a = game.rating_a,
        rating_b = game.rating_b,
        odds_a   = game.odds_a,
        odds_b   = game.odds_b,
        total_line = game.total_line,
        spread     = game.spread,
    )
    return analysis


@app.post("/simulate")
async def simulate(game: GameInput):
    """Monte Carlo simulation — returns histogram data for charting."""
    pa, pb = engine.elo_prob(game.rating_a, game.rating_b)
    N = 10_000
    buckets_a = [0] * 10   # 0-9%, 10-19% ... 90-99%
    for _ in range(N):
        buckets_a[int(random.random() < pa)] += 1

    wins_a = sum(1 for _ in range(N) if random.random() < pa)
    wins_b = N - wins_a

    return {
        "simulations": N,
        "team_a": game.team_a,
        "team_b": game.team_b,
        "win_rate_a": round(wins_a / N, 4),
        "win_rate_b": round(wins_b / N, 4),
        "margin_distribution": {
            "mean_prob_a": pa,
            "std_dev": round(math.sqrt(pa * pb / N), 4),
        },
    }


# ─────────────────────────────────────────────
#  Bet Types
# ─────────────────────────────────────────────

@app.post("/bets/moneyline")
async def moneyline(game: GameInput):
    pa, pb   = engine.elo_prob(game.rating_a, game.rating_b)
    ev_a     = engine.ev(pa, game.odds_a)
    ev_b     = engine.ev(pb, game.odds_b)
    best_ev  = max(ev_a, ev_b)
    best_team = game.team_a if ev_a >= ev_b else game.team_b
    conf     = engine.confidence_level(best_ev, pa if ev_a >= ev_b else pb)
    return {
        "bet_type": "moneyline",
        "team_a": {"team": game.team_a, "odds": game.odds_a, "prob": pa, "ev": ev_a, "implied": engine.implied_prob(game.odds_a)},
        "team_b": {"team": game.team_b, "odds": game.odds_b, "prob": pb, "ev": ev_b, "implied": engine.implied_prob(game.odds_b)},
        "recommendation": {"selection": best_team, "ev": best_ev, "confidence": conf, "units": engine.units(conf)},
    }


@app.post("/bets/spread")
async def spread_bet(game: GameInput):
    if game.spread is None:
        raise HTTPException(400, "spread field required")
    pa, pb = engine.elo_prob(game.rating_a, game.rating_b)
    spread_analysis = engine._analyze_spread(game.sport, game.spread, pa)
    ev_fav = engine.ev(pa, game.odds_a)
    ev_dog = engine.ev(pb, game.odds_b)
    return {
        "bet_type": "spread",
        "spread":   game.spread,
        "favorite": {"team": game.team_a, "prob": pa, "ev": ev_fav, "odds": game.odds_a},
        "dog":      {"team": game.team_b, "prob": pb, "ev": ev_dog, "odds": game.odds_b},
        "key_number_analysis": spread_analysis,
        "recommendation": {
            "play": "favorite" if ev_fav > ev_dog and ev_fav > 0 else "dog" if ev_dog > 0 else "pass",
            "reason": spread_analysis,
        },
    }


@app.post("/bets/total")
async def total_bet(game: GameInput):
    if game.total_line is None:
        raise HTTPException(400, "total_line field required")
    total_analysis = engine._analyze_total(game.sport, game.total_line)
    # Default 50/50 for over/under unless model data provided
    over_prob  = 0.50
    under_prob = 0.50
    ev_over    = engine.ev(over_prob, game.odds_a)   # odds_a = over odds
    ev_under   = engine.ev(under_prob, game.odds_b)  # odds_b = under odds
    return {
        "bet_type": "total",
        "line":    game.total_line,
        "over":    {"prob": over_prob,  "odds": game.odds_a, "ev": ev_over},
        "under":   {"prob": under_prob, "odds": game.odds_b, "ev": ev_under},
        "key_number_analysis": total_analysis,
        "recommendation": {
            "play":   "over" if ev_over > ev_under and ev_over > 0 else "under" if ev_under > 0 else "pass",
            "caution": total_analysis["near_key_number"],
        },
    }


@app.post("/bets/parlay")
async def parlay(inp: ParlayInput):
    """Calculate parlay EV — most parlays are -EV, shown transparently."""
    combined_prob = 1.0
    combined_odds = 1.0
    for leg in inp.legs:
        combined_prob *= leg.prob
        combined_odds *= leg.odds
    ev = engine.ev(combined_prob, combined_odds)
    vig_per_leg = [(1 / l.odds) - l.prob for l in inp.legs]
    return {
        "bet_type":      "parlay",
        "legs":          len(inp.legs),
        "combined_odds": round(combined_odds, 3),
        "combined_prob": round(combined_prob, 4),
        "ev":            ev,
        "units":         inp.units,
        "payout":        round(combined_odds * inp.units, 2),
        "vig_per_leg":   [round(v, 4) for v in vig_per_leg],
        "warning":       "Parlays are -EV in most cases. Only use when legs are correlated." if ev < 0 else "Positive EV parlay found.",
        "recommendation": "PASS" if ev < -0.05 else "CONSIDER",
    }


@app.post("/bets/prop")
async def player_prop(inp: PropInput):
    """Player prop analysis."""
    ev_over  = engine.ev(inp.over_prob, inp.over_odds)
    ev_under = engine.ev(1 - inp.over_prob, inp.under_odds)
    conf     = engine.confidence_level(max(ev_over, ev_under), inp.over_prob)
    return {
        "bet_type": "player_prop",
        "player":   inp.player,
        "stat":     inp.stat,
        "line":     inp.line,
        "over":     {"prob": inp.over_prob,        "odds": inp.over_odds,  "ev": ev_over},
        "under":    {"prob": 1 - inp.over_prob,    "odds": inp.under_odds, "ev": ev_under},
        "recommendation": {
            "play":       "over" if ev_over >= ev_under else "under",
            "ev":         max(ev_over, ev_under),
            "confidence": conf,
            "units":      engine.units(conf),
        },
    }


@app.post("/bets/futures")
async def futures(game: GameInput):
    """Futures/outrights — models implied prob vs market price."""
    pa, _ = engine.elo_prob(game.rating_a, game.rating_b)
    ev_a  = engine.ev(pa, game.odds_a)
    conf  = engine.confidence_level(ev_a, pa)
    return {
        "bet_type":    "futures",
        "team":        game.team_a,
        "model_prob":  pa,
        "market_odds": game.odds_a,
        "implied_prob": engine.implied_prob(game.odds_a),
        "ev":          ev_a,
        "confidence":  conf,
        "units":       engine.units(conf),
        "note": "Futures carry high variance — use reduced sizing and track CLV.",
    }


@app.post("/bets/teaser")
async def teaser(game: GameInput):
    """NFL/NBA teaser analysis (6pt NFL, 4pt NBA standard)."""
    TEASER_PTS = {"nfl": 6, "nba": 4}
    pts = TEASER_PTS.get(game.sport.lower(), 6)
    if game.spread is None:
        raise HTTPException(400, "spread required for teaser")
    adjusted_spread = game.spread - pts   # favorable direction
    pa, pb = engine.elo_prob(game.rating_a, game.rating_b)
    return {
        "bet_type":        "teaser",
        "sport":           game.sport,
        "teaser_points":   pts,
        "original_spread": game.spread,
        "adjusted_spread": adjusted_spread,
        "standard_teaser_odds": -110 if game.sport.lower() == "nfl" else -110,
        "warning": "Teasers through key numbers (3, 7) offer value in NFL. Otherwise typically -EV.",
        "crosses_key_number": any(
            min(game.spread, adjusted_spread) <= k <= max(game.spread, adjusted_spread)
            for k in engine.KEY_NUMBERS.get("nfl_spread", [])
        ),
    }


@app.post("/bets/live")
async def live_bet(game: GameInput):
    """Pre-game to live odds conversion guide — CLV tracking."""
    pa, _ = engine.elo_prob(game.rating_a, game.rating_b)
    return {
        "bet_type":   "live_context",
        "pregame_model_prob": pa,
        "pregame_odds": game.odds_a,
        "pregame_ev": engine.ev(pa, game.odds_a),
        "warning": "Live betting requires real-time feeds. Use pre-game analysis as baseline only.",
        "clv_tracking": "Compare closing line to your bet price to measure edge quality over time.",
    }


# ─────────────────────────────────────────────
#  Odds Utilities
# ─────────────────────────────────────────────

@app.get("/odds/convert")
def convert_odds(american: Optional[int] = None, decimal: Optional[float] = None, fractional: Optional[str] = None):
    """Universal odds converter."""
    result = {}
    if american is not None:
        dec = engine.american_to_decimal(american)
        result = {
            "american": american,
            "decimal":  dec,
            "fractional": f"{int((dec-1)*100)}/100",
            "implied_prob": engine.implied_prob(dec),
        }
    elif decimal is not None:
        am = int((decimal - 1) * 100) if decimal >= 2 else int(-100 / (decimal - 1))
        result = {
            "american": am,
            "decimal":  decimal,
            "implied_prob": engine.implied_prob(decimal),
        }
    elif fractional is not None:
        num, den = map(int, fractional.split("/"))
        dec = (num / den) + 1
        result = {
            "fractional": fractional,
            "decimal":    dec,
            "american":   int((dec - 1) * 100) if dec >= 2 else int(-100 / (dec - 1)),
            "implied_prob": engine.implied_prob(dec),
        }
    return result


@app.get("/odds/ev")
def calculate_ev(prob: float, decimal_odds: float):
    return {
        "prob":         prob,
        "decimal_odds": decimal_odds,
        "ev":           engine.ev(prob, decimal_odds),
        "kelly":        engine.kelly_criterion(prob, decimal_odds),
        "verdict":      "bet" if engine.ev(prob, decimal_odds) > 0 else "pass",
    }


@app.get("/odds/kelly")
def kelly(prob: float, decimal_odds: float, bankroll: float = 1000, fraction: float = 0.25):
    k = engine.kelly_criterion(prob, decimal_odds, fraction)
    return {
        "kelly_fraction": k,
        "units":          round(k * 100, 2),
        "dollar_amount":  round(k * bankroll, 2),
        "full_kelly":     engine.kelly_criterion(prob, decimal_odds, 1.0),
        "fractional_kelly_used": fraction,
    }


# ─────────────────────────────────────────────
#  Bankroll & Bet Tracking
# ─────────────────────────────────────────────

@app.post("/tracker/save")
def save_bet(bet: BetRecord):
    rid = db.insert("bet_tracker", {
        "matchup":        bet.matchup,
        "sport":          bet.sport,
        "bet_type":       bet.bet_type,
        "selection":      bet.selection,
        "odds":           bet.odds,
        "units":          bet.units,
        "predicted_prob": bet.predicted_prob,
        "ev":             bet.ev,
        "confidence":     bet.confidence,
        "game_id":        bet.game_id or "",
    })
    return {"saved": True, "id": rid}


@app.post("/tracker/settle")
def settle_bet(upd: OutcomeUpdate):
    rows = db.execute("SELECT * FROM bet_tracker WHERE id=?", (upd.bet_id,))
    if not rows:
        raise HTTPException(404, "Bet not found")
    row = rows[0]
    pnl = (row["odds"] - 1) * row["units"] if upd.outcome == "win" else -row["units"] if upd.outcome == "loss" else 0
    db.update("bet_tracker", upd.bet_id, {
        "outcome":    upd.outcome,
        "profit_loss": pnl,
        "settled_at": datetime.now().isoformat(),
    })
    return {"settled": True, "profit_loss": pnl}


@app.get("/tracker/history")
def bet_history(limit: int = 50):
    rows = db.execute("SELECT * FROM bet_tracker ORDER BY created_at DESC LIMIT ?", (limit,))
    return [dict(r) for r in rows]


@app.get("/tracker/stats")
def bankroll_stats():
    rows = db.execute("SELECT * FROM bet_tracker WHERE outcome IS NOT NULL")
    if not rows:
        return {"message": "No settled bets yet"}
    total_bets    = len(rows)
    wins          = sum(1 for r in rows if r["outcome"] == "win")
    total_pnl     = sum(r["profit_loss"] or 0 for r in rows)
    total_units   = sum(r["units"] for r in rows)
    roi           = (total_pnl / total_units * 100) if total_units > 0 else 0
    by_confidence = {}
    for r in rows:
        c = r["confidence"] or "unknown"
        if c not in by_confidence:
            by_confidence[c] = {"n": 0, "wins": 0, "pnl": 0}
        by_confidence[c]["n"]    += 1
        by_confidence[c]["wins"] += 1 if r["outcome"] == "win" else 0
        by_confidence[c]["pnl"]  += r["profit_loss"] or 0
    return {
        "total_bets": total_bets,
        "wins":       wins,
        "losses":     total_bets - wins,
        "win_rate":   round(wins / total_bets, 3),
        "total_pnl":  round(total_pnl, 2),
        "roi_pct":    round(roi, 2),
        "by_confidence": by_confidence,
        "clv_note": "Track closing line value to measure edge quality over time.",
    }


# ─────────────────────────────────────────────
#  Research (proxies to Claude API on frontend)
# ─────────────────────────────────────────────

@app.get("/research/patterns")
def get_patterns():
    rows = db.execute("SELECT * FROM learning_patterns ORDER BY discovered_at DESC LIMIT 20")
    return [dict(r) for r in rows]


@app.get("/research/schedule_spots")
def schedule_spots():
    """Returns known situational edge frameworks."""
    return {
        "nba": [
            {"spot": "back_to_back", "description": "Team on second of back-to-back, especially road", "avg_edge_pts": -2.3},
            {"spot": "4_in_5",       "description": "4 games in 5 nights fatigue spot",               "avg_edge_pts": -1.8},
            {"spot": "rest_advantage","description": "3+ days rest vs back-to-back",                   "avg_edge_pts": 2.5},
        ],
        "nfl": [
            {"spot": "short_week",   "description": "Thursday game after Sunday — short week",         "avg_edge_pts": -1.5},
            {"spot": "bye_week",     "description": "Coming off bye — well rested, scheme advantage",  "avg_edge_pts": 1.8},
            {"spot": "divisional",   "description": "Divisional familiarity reduces underdog spread",  "avg_edge_pts": 1.0},
        ],
        "mlb": [
            {"spot": "bullpen_fatigue", "description": "3+ high-leverage games in 4 days",            "avg_edge_pts": 0.4},
            {"spot": "ace_return",      "description": "Ace returning from rest vs avg starter",       "avg_edge_pts": -0.8},
        ],
    }


# ─────────────────────────────────────────────
#  Static frontend
# ─────────────────────────────────────────────

try:
    app.mount("/static", StaticFiles(directory="frontend"), name="static")

    @app.get("/app")
    def serve_app():
        return FileResponse("frontend/index.html")
except Exception:
    pass  # Frontend not built yet


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
