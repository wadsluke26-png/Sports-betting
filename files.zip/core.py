#!/usr/bin/env python3
"""
Sports Prophet — Autonomous Operations Core
Handles scheduling, database, search orchestration, analysis, and learning.
"""

import asyncio
import hashlib
import json
import logging
import random
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("sports_prophet.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("SportsProphet")


# ─────────────────────────────────────────────
#  Enums & Dataclasses
# ─────────────────────────────────────────────

class TaskPriority(Enum):
    CRITICAL   = auto()
    HIGH       = auto()
    MEDIUM     = auto()
    LOW        = auto()
    BACKGROUND = auto()


@dataclass
class ScheduledTask:
    name:            str
    priority:        TaskPriority
    cron_expression: str
    handler:         Callable
    id:              str = ""
    last_run:        Optional[datetime] = None
    next_run:        Optional[datetime] = None
    enabled:         bool = True
    metadata:        Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.id:
            self.id = hashlib.md5(f"{self.name}_{time.time()}".encode()).hexdigest()[:12]


# ─────────────────────────────────────────────
#  Database
# ─────────────────────────────────────────────

class DatabaseManager:
    """SQLite persistence layer."""

    SCHEMA = """
        CREATE TABLE IF NOT EXISTS games (
            id TEXT PRIMARY KEY,
            sport TEXT NOT NULL,
            home_team TEXT NOT NULL,
            away_team TEXT NOT NULL,
            game_time TIMESTAMP NOT NULL,
            status TEXT DEFAULT 'scheduled',
            stadium TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS injuries (
            id TEXT PRIMARY KEY,
            player_name TEXT NOT NULL,
            team TEXT NOT NULL,
            sport TEXT,
            injury_type TEXT,
            status TEXT,
            expected_return TEXT,
            source_url TEXT,
            reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_verified TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS line_movements (
            id TEXT PRIMARY KEY,
            game_id TEXT NOT NULL,
            bookmaker TEXT NOT NULL,
            line_type TEXT,
            open_line REAL,
            current_line REAL,
            line_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            movement_reason TEXT
        );
        CREATE TABLE IF NOT EXISTS analyses (
            id TEXT PRIMARY KEY,
            game_id TEXT NOT NULL,
            analysis_type TEXT,
            content TEXT,
            confidence_level TEXT,
            edge_assessment TEXT,
            bet_type TEXT,
            recommended_units REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resulted BOOLEAN DEFAULT FALSE,
            result_accuracy REAL
        );
        CREATE TABLE IF NOT EXISTS bet_tracker (
            id TEXT PRIMARY KEY,
            game_id TEXT,
            matchup TEXT NOT NULL,
            sport TEXT,
            bet_type TEXT NOT NULL,
            selection TEXT NOT NULL,
            odds REAL NOT NULL,
            units REAL NOT NULL,
            predicted_prob REAL,
            ev REAL,
            confidence TEXT,
            outcome TEXT,
            profit_loss REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            settled_at TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS learning_patterns (
            id TEXT PRIMARY KEY,
            pattern_type TEXT NOT NULL,
            sport TEXT,
            pattern_data TEXT,
            success_rate REAL,
            sample_size INTEGER,
            discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_validated TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS user_queries (
            id TEXT PRIMARY KEY,
            query_text TEXT NOT NULL,
            query_type TEXT,
            response_quality_score REAL,
            processing_time_ms INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS system_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            level TEXT NOT NULL,
            component TEXT,
            message TEXT NOT NULL,
            metadata TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_games_time    ON games(game_time);
        CREATE INDEX IF NOT EXISTS idx_injuries_team ON injuries(team);
        CREATE INDEX IF NOT EXISTS idx_lines_game    ON line_movements(game_id);
        CREATE INDEX IF NOT EXISTS idx_bets_created  ON bet_tracker(created_at);
    """

    def __init__(self, db_path: str = "sports_prophet.db"):
        self.db_path = db_path
        self._init()

    def _init(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript(self.SCHEMA)

    def _uid(self) -> str:
        return hashlib.md5(f"{time.time()}_{random.random()}".encode()).hexdigest()[:16]

    def execute(self, query: str, params: Tuple = ()) -> List[sqlite3.Row]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            return conn.execute(query, params).fetchall()

    def insert(self, table: str, data: Dict[str, Any]) -> str:
        rid = self._uid()
        data = {"id": rid, **data}
        cols = ", ".join(data.keys())
        vals = ", ".join(["?"] * len(data))
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({vals})", tuple(data.values()))
            conn.commit()
        return rid

    def update(self, table: str, record_id: str, data: Dict[str, Any]):
        sets = ", ".join([f"{k}=?" for k in data.keys()])
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(f"UPDATE {table} SET {sets} WHERE id=?", (*data.values(), record_id))
            conn.commit()


# ─────────────────────────────────────────────
#  Search Orchestrator
# ─────────────────────────────────────────────

class SearchOrchestrator:
    """Manages external data retrieval with caching and rate limiting."""

    CACHE_TTL = timedelta(minutes=15)

    def __init__(self, db: DatabaseManager):
        self.db = db
        self._cache: Dict[str, Tuple[Any, datetime]] = {}
        self._rate: Dict[str, datetime] = {}

    def _cache_key(self, qtype: str, params: Dict) -> str:
        return f"{qtype}_{hashlib.md5(json.dumps(params, sort_keys=True).encode()).hexdigest()[:16]}"

    async def search(self, query_type: str, params: Dict[str, Any]) -> Dict[str, Any]:
        key = self._cache_key(query_type, params)
        if key in self._cache:
            result, ts = self._cache[key]
            if datetime.now() - ts < self.CACHE_TTL:
                return result
        if query_type in self._rate:
            wait = (self._rate[query_type] - datetime.now()).total_seconds()
            if wait > 0:
                await asyncio.sleep(wait)
        handlers = {
            "injuries":      self._injuries,
            "weather":       self._weather,
            "odds":          self._odds,
            "schedule":      self._schedule,
            "team_stats":    self._team_stats,
            "player_stats":  self._player_stats,
            "line_movement": self._line_movement,
        }
        result = await handlers.get(query_type, self._default)(params)
        self._cache[key] = (result, datetime.now())
        self._rate[query_type] = datetime.now() + timedelta(seconds=2)
        return result

    # ── Stub implementations (replace with real API calls) ──────────────────

    async def _injuries(self, p: Dict) -> Dict:
        return {"source": "aggregated", "timestamp": datetime.now().isoformat(), "injuries": [], "confidence": "high"}

    async def _weather(self, p: Dict) -> Dict:
        return {"stadium": p.get("stadium"), "forecast": {}, "impact_assessment": None}

    async def _odds(self, p: Dict) -> Dict:
        return {"game_id": p.get("game_id"), "books": ["draftkings", "fanduel", "betmgm", "caesars"], "lines": {}, "best_lines": {}, "line_movement": []}

    async def _schedule(self, p: Dict) -> Dict:
        return {"team": p.get("team"), "games": [], "rest_days": 0, "travel_miles": 0, "back_to_back": False}

    async def _team_stats(self, p: Dict) -> Dict:
        return {"team": p.get("team"), "last_10": {}, "home_away_splits": {}, "situational_stats": {}}

    async def _player_stats(self, p: Dict) -> Dict:
        return {"player": p.get("player"), "recent_form": {}, "injury_history": {}, "matchup_history": {}}

    async def _line_movement(self, p: Dict) -> Dict:
        return {"movements": [], "steam_moves": [], "reverse_line_movement": []}

    async def _default(self, p: Dict) -> Dict:
        return {"error": "unknown query type", "params": p}


# ─────────────────────────────────────────────
#  Analysis Engine
# ─────────────────────────────────────────────

class AnalysisEngine:
    """Core analysis logic — Elo prediction, EV, situational edges."""

    KEY_NUMBERS = {
        "nfl_spread": [3, 7, 10, 6, 4, 14],
        "nfl_total":  [41, 44, 47, 51],
        "nba_spread": [1.5, 2.5, 3.5, 4.5, 5.5],
        "mlb_total":  [7, 8, 9, 8.5],
        "nhl_total":  [5, 5.5, 6],
        "soccer":     [0.5, 1.5, 2.5],
    }

    def __init__(self, db: DatabaseManager, search: SearchOrchestrator):
        self.db = db
        self.search = search

    # ── Probability models ───────────────────────────────────────────────────

    @staticmethod
    def elo_prob(rating_a: float, rating_b: float) -> Tuple[float, float]:
        pa = 1 / (1 + 10 ** (-(rating_a - rating_b) / 400))
        return round(pa, 4), round(1 - pa, 4)

    @staticmethod
    def monte_carlo(prob_a: float, simulations: int = 10_000) -> Tuple[float, float]:
        wins = sum(1 for _ in range(simulations) if random.random() < prob_a)
        return round(wins / simulations, 4), round(1 - wins / simulations, 4)

    @staticmethod
    def ev(prob: float, decimal_odds: float) -> float:
        return round(prob * decimal_odds - (1 - prob), 4)

    @staticmethod
    def american_to_decimal(odds: int) -> float:
        return round((odds / 100) + 1 if odds > 0 else (100 / abs(odds)) + 1, 3)

    @staticmethod
    def implied_prob(decimal_odds: float) -> float:
        return round(1 / decimal_odds, 4)

    @staticmethod
    def kelly_criterion(prob: float, decimal_odds: float, fraction: float = 0.25) -> float:
        """Fractional Kelly for unit sizing."""
        b = decimal_odds - 1
        q = 1 - prob
        k = (b * prob - q) / b
        return max(0, round(k * fraction, 3))

    def confidence_level(self, ev_val: float, prob: float) -> str:
        conf = abs(prob - 0.5) * 2
        if ev_val > 0.1 and conf > 0.3:
            return "HIGH"
        if ev_val > 0.02 and conf > 0.15:
            return "MEDIUM"
        if ev_val > 0:
            return "LOW"
        return "PASS"

    def units(self, confidence: str) -> float:
        return {"HIGH": 2.5, "MEDIUM": 1.5, "LOW": 0.75, "PASS": 0.0}[confidence]

    async def full_game_analysis(
        self,
        sport: str,
        team_a: str,
        team_b: str,
        rating_a: float,
        rating_b: float,
        odds_a: float,
        odds_b: float,
        total_line: Optional[float] = None,
        spread: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Full structured analysis following the research protocol."""

        # Gather data in parallel
        inj_a, inj_b, sched_a, sched_b, odds_data = await asyncio.gather(
            self.search.search("injuries",  {"teams": [team_a]}),
            self.search.search("injuries",  {"teams": [team_b]}),
            self.search.search("schedule",  {"team": team_a}),
            self.search.search("schedule",  {"team": team_b}),
            self.search.search("odds",      {"teams": [team_a, team_b]}),
        )

        pa, pb = self.elo_prob(rating_a, rating_b)
        sim_a, sim_b = self.monte_carlo(pa)
        ev_a = self.ev(pa, odds_a)
        ev_b = self.ev(pb, odds_b)
        conf_a = self.confidence_level(ev_a, pa)
        conf_b = self.confidence_level(ev_b, pb)
        best = (team_a, ev_a, conf_a, odds_a, pa) if ev_a >= ev_b else (team_b, ev_b, conf_b, odds_b, pb)

        analysis = {
            "sport":      sport,
            "matchup":    f"{team_a} vs {team_b}",
            "date":       datetime.now().isoformat(),
            "quick_summary": {
                "edge_assessment": f"{'Lean ' + best[0] if best[1] > 0 else 'No clear edge'}",
                "key_factors": [
                    f"Elo win prob: {team_a} {pa*100:.1f}% / {team_b} {pb*100:.1f}%",
                    f"EV: {team_a} {ev_a:+.3f} / {team_b} {ev_b:+.3f}",
                    f"Simulation (10k): {team_a} {sim_a*100:.1f}% / {team_b} {sim_b*100:.1f}%",
                ],
                "confidence": best[2],
                "recommended_units": self.units(best[2]),
            },
            "probabilities": {
                team_a: {"model": pa, "simulation": sim_a, "implied": self.implied_prob(odds_a)},
                team_b: {"model": pb, "simulation": sim_b, "implied": self.implied_prob(odds_b)},
            },
            "expected_value":    {team_a: ev_a, team_b: ev_b},
            "kelly_sizing":      {team_a: self.kelly_criterion(pa, odds_a), team_b: self.kelly_criterion(pb, odds_b)},
            "confidence_levels": {team_a: conf_a, team_b: conf_b},
            "injury_data":       {"team_a": inj_a, "team_b": inj_b},
            "schedule_data":     {"team_a": sched_a, "team_b": sched_b},
            "market_snapshot":   odds_data,
            "recommendation": {
                "selection": best[0] if best[1] > 0 else "PASS",
                "bet_type":  "moneyline",
                "odds":      best[3],
                "units":     self.units(best[2]),
                "ev":        best[1],
                "confidence": best[2],
                "reasoning": self._reasoning(best[2], best[0], best[1]),
            },
        }

        # Add totals if line provided
        if total_line is not None:
            analysis["total_analysis"] = self._analyze_total(sport, total_line)

        # Add spread if provided
        if spread is not None:
            analysis["spread_analysis"] = self._analyze_spread(sport, spread, pa)

        return analysis

    def _reasoning(self, conf: str, team: str, ev: float) -> str:
        if conf == "PASS":
            return "No identifiable edge. Bookmaker pricing offers no value at current lines."
        if conf == "HIGH":
            return f"Multiple edges align on {team}. EV of {ev:+.3f} at current price with strong model conviction."
        if conf == "MEDIUM":
            return f"Solid spot on {team} with EV of {ev:+.3f}. Monitor for injury updates before game time."
        return f"Marginal edge on {team} (EV {ev:+.3f}). Reduce sizing and wait for better number."

    def _analyze_total(self, sport: str, line: float) -> Dict:
        key_nums = self.KEY_NUMBERS.get(f"{sport}_total", [])
        proximity = min((abs(line - k) for k in key_nums), default=None)
        return {
            "line": line,
            "key_number_proximity": proximity,
            "near_key_number": proximity is not None and proximity < 0.5,
            "recommendation": "avoid" if (proximity is not None and proximity < 0.5) else "evaluate",
        }

    def _analyze_spread(self, sport: str, spread: float, win_prob: float) -> Dict:
        key_nums = self.KEY_NUMBERS.get(f"{sport}_spread", [])
        proximity = min((abs(abs(spread) - k) for k in key_nums), default=None)
        return {
            "spread": spread,
            "key_number_proximity": proximity,
            "near_key_number": proximity is not None and proximity < 0.5,
        }


# ─────────────────────────────────────────────
#  Learning Engine
# ─────────────────────────────────────────────

class LearningEngine:
    """Pattern recognition and self-improvement."""

    MIN_SAMPLE = 30

    def __init__(self, db: DatabaseManager):
        self.db = db

    async def run_all(self):
        await asyncio.gather(
            self._rest_advantage(),
            self._injury_impact(),
            self._line_movement_patterns(),
            self._situational_spots(),
        )

    async def _rest_advantage(self):
        rows = self.db.execute("""
            SELECT b.*, g.sport FROM bet_tracker b
            LEFT JOIN games g ON b.game_id = g.id
            WHERE b.outcome IS NOT NULL
        """)
        if len(rows) < self.MIN_SAMPLE:
            return
        wins = sum(1 for r in rows if r["outcome"] == "win")
        self._store("rest_advantage", "all", {
            "win_rate": wins / len(rows),
            "sample_size": len(rows),
        })

    async def _injury_impact(self):
        pass  # Requires enriched injury + outcome correlation data

    async def _line_movement_patterns(self):
        pass  # Requires historical line snapshots

    async def _situational_spots(self):
        pass  # Requires schedule + outcome correlation

    def _store(self, ptype: str, sport: str, data: Dict):
        self.db.insert("learning_patterns", {
            "pattern_type":   ptype,
            "sport":          sport,
            "pattern_data":   json.dumps(data),
            "success_rate":   data.get("win_rate", 0),
            "sample_size":    data.get("sample_size", 0),
            "last_validated": datetime.now().isoformat(),
        })
        logger.info(f"Pattern stored: {ptype} / {sport}")


# ─────────────────────────────────────────────
#  Autonomous Scheduler
# ─────────────────────────────────────────────

class AutonomousScheduler:
    """Event-loop-based task scheduler."""

    PRIORITY_ORDER = {
        TaskPriority.CRITICAL:   0,
        TaskPriority.HIGH:       1,
        TaskPriority.MEDIUM:     2,
        TaskPriority.LOW:        3,
        TaskPriority.BACKGROUND: 4,
    }

    def __init__(self):
        self.db       = DatabaseManager()
        self.search   = SearchOrchestrator(self.db)
        self.analysis = AnalysisEngine(self.db, self.search)
        self.learning = LearningEngine(self.db)
        self.tasks:  Dict[str, ScheduledTask] = {}
        self.running = False
        self._register_defaults()

    def _register_defaults(self):
        defs = [
            ("daily_morning_protocol", TaskPriority.CRITICAL,   "daily_06:00",      self._morning_protocol),
            ("injury_monitor",         TaskPriority.CRITICAL,   "every_15_min",     self._injury_monitor),
            ("line_tracker",           TaskPriority.HIGH,        "every_10_min",     self._line_tracker),
            ("weather_monitor",        TaskPriority.MEDIUM,      "every_6_hours",    self._weather_monitor),
            ("pattern_learning",       TaskPriority.BACKGROUND,  "daily_03:00",      self._pattern_learning),
            ("performance_audit",      TaskPriority.BACKGROUND,  "weekly_sun_05:00", self._performance_audit),
        ]
        for name, priority, cron, handler in defs:
            t = ScheduledTask(name=name, priority=priority, cron_expression=cron, handler=handler)
            t.next_run = self._next(cron)
            self.tasks[t.id] = t
            logger.info(f"Registered: {name}")

    def _next(self, cron: str) -> datetime:
        now = datetime.now()
        if cron.startswith("daily_"):
            h, m = map(int, cron[6:].split(":"))
            target = now.replace(hour=h, minute=m, second=0, microsecond=0)
            return target if target > now else target + timedelta(days=1)
        if cron == "every_15_min":  return now + timedelta(minutes=15)
        if cron == "every_10_min":  return now + timedelta(minutes=10)
        if cron == "every_6_hours": return now + timedelta(hours=6)
        if cron.startswith("weekly_"):
            parts = cron.split("_")
            dow  = ["mon","tue","wed","thu","fri","sat","sun"].index(parts[1])
            h, m = map(int, parts[2].split(":"))
            days = (dow - now.weekday()) % 7 or 7
            return (now + timedelta(days=days)).replace(hour=h, minute=m, second=0)
        return now + timedelta(hours=1)

    async def run(self):
        self.running = True
        logger.info("Sports Prophet scheduler started")
        while self.running:
            now = datetime.now()
            due = sorted(
                [t for t in self.tasks.values() if t.enabled and t.next_run and t.next_run <= now],
                key=lambda t: self.PRIORITY_ORDER[t.priority],
            )
            for task in due:
                asyncio.create_task(self._execute(task))
            await asyncio.sleep(60)

    async def _execute(self, task: ScheduledTask):
        logger.info(f"Running: {task.name}")
        try:
            task.last_run = datetime.now()
            await task.handler()
            task.next_run = self._next(task.cron_expression)
        except Exception as e:
            logger.error(f"Task {task.name} failed: {e}")

    def stop(self):
        self.running = False
        logger.info("Scheduler stopped")

    # ── Task handlers ────────────────────────────────────────────────────────

    async def _morning_protocol(self):
        logger.info("Morning protocol: scanning overnight news, lines, weather")
        await asyncio.gather(
            self.search.search("injuries",      {"sport": "all"}),
            self.search.search("line_movement", {}),
            self.search.search("weather",       {}),
        )

    async def _injury_monitor(self):
        await self.search.search("injuries", {"sport": "all"})

    async def _line_tracker(self):
        await self.search.search("line_movement", {})

    async def _weather_monitor(self):
        await self.search.search("weather", {})

    async def _pattern_learning(self):
        await self.learning.run_all()

    async def _performance_audit(self):
        rows = self.db.execute("""
            SELECT confidence, COUNT(*) as n,
                   SUM(CASE WHEN outcome='win' THEN 1 ELSE 0 END) as wins
            FROM bet_tracker WHERE outcome IS NOT NULL
            GROUP BY confidence
        """)
        for r in rows:
            logger.info(f"Audit — {r['confidence']}: {r['wins']}/{r['n']} ({r['wins']/r['n']*100:.1f}%)")


# ─────────────────────────────────────────────
#  Entry Point
# ─────────────────────────────────────────────

async def main():
    Path("sports_betting_data").mkdir(exist_ok=True)
    scheduler = AutonomousScheduler()
    try:
        await scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    asyncio.run(main())
